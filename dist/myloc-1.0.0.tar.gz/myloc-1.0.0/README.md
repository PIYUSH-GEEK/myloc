# my-location
A python package that will show the location of the user.
This package contains pre-defined functions that will show the location of the user.
It will show the IP Address, latitude, longitude, etc.
